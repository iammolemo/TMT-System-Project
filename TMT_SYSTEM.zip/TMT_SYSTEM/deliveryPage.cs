﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;


namespace TMT_SYSTEM
{
    public partial class deliveryPage : Form
    {
        SqlConnection con;
        string conString = @"Data Source=DESKTOP-DQF9S0M;Initial Catalog=TMT;Integrated Security=True";
        SqlCommand cmd;
        SqlDataReader myReader;
        public deliveryPage()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void okBtn_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(conString);
                con.Open();
                if (txtEmail.Text != "")
                {

                    string email = txtEmail.Text;


                    string query = "SELECT * from [SCHOOL] WHERE email ='" + txtEmail.Text + "'";

                    if (txtEmail.Text == email)
                    {
                        cmd = new SqlCommand(query, con);
                        myReader = cmd.ExecuteReader();
                        if (myReader.HasRows)
                        {

                            lblConfirmAdd.Visible = true;
                            grpschoolAdd.Visible = true;
                            lblOne.Visible = true;
                            lblLine1.Visible = true;
                            lblLine2.Visible = true;
                            lblTwo.Visible = true;
                            lblProv.Visible = true;
                            lblProvince.Visible = true;
                            lblCode.Visible = true;
                            lblPCode.Visible = true;
                            lblError.Visible = false;
                        }
                        else
                        {
                            lblError.Visible = true;
                        }

                    }
                    else
                    {
                        MessageBox.Show("Sorry, Username and password you entered doesn't belong to an account. Please double-check Your details and try again.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                else
                {
                    MessageBox.Show("The Username or Password is empty", "Information");
                }
                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




        private void btnYes_Click(object sender, EventArgs e)
        {
            this.Hide();
            confirmOrderPage confirm = new confirmOrderPage();
            confirm.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            deliveryCollectionPage dc = new deliveryCollectionPage();
            dc.ShowDialog();
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please make sure that you've entered the correct email address.");
            txtEmail.Text = "";
            txtEmail.Focus();
        }
    }
}

