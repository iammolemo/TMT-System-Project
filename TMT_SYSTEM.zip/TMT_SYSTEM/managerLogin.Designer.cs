﻿namespace TMT_SYSTEM
{
    partial class managerLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMaintainEmp = new System.Windows.Forms.Button();
            this.btnMaintainOrder = new System.Windows.Forms.Button();
            this.BtnMaintainSupp = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPrev = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMaintainEmp
            // 
            this.btnMaintainEmp.Location = new System.Drawing.Point(94, 51);
            this.btnMaintainEmp.Name = "btnMaintainEmp";
            this.btnMaintainEmp.Size = new System.Drawing.Size(181, 32);
            this.btnMaintainEmp.TabIndex = 0;
            this.btnMaintainEmp.Text = "MAINTAIN EMPLOYEES";
            this.btnMaintainEmp.UseVisualStyleBackColor = true;
            // 
            // btnMaintainOrder
            // 
            this.btnMaintainOrder.Location = new System.Drawing.Point(94, 105);
            this.btnMaintainOrder.Name = "btnMaintainOrder";
            this.btnMaintainOrder.Size = new System.Drawing.Size(181, 35);
            this.btnMaintainOrder.TabIndex = 1;
            this.btnMaintainOrder.Text = "MAINTAIN ORDERS";
            this.btnMaintainOrder.UseVisualStyleBackColor = true;
            // 
            // BtnMaintainSupp
            // 
            this.BtnMaintainSupp.Location = new System.Drawing.Point(94, 163);
            this.BtnMaintainSupp.Name = "BtnMaintainSupp";
            this.BtnMaintainSupp.Size = new System.Drawing.Size(181, 38);
            this.BtnMaintainSupp.TabIndex = 3;
            this.BtnMaintainSupp.Text = "MAINTAIN SUPPLIERS";
            this.BtnMaintainSupp.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnMaintainEmp);
            this.panel1.Controls.Add(this.btnMaintainOrder);
            this.panel1.Controls.Add(this.BtnMaintainSupp);
            this.panel1.Location = new System.Drawing.Point(121, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 244);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(234, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "MANAGER LOGIN";
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(44, 345);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(123, 33);
            this.btnPrev.TabIndex = 6;
            this.btnPrev.Text = "PREVIOUS PAGE";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // managerLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 390);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "managerLogin";
            this.Text = "managerLogin";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMaintainEmp;
        private System.Windows.Forms.Button btnMaintainOrder;
        private System.Windows.Forms.Button BtnMaintainSupp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPrev;
    }
}