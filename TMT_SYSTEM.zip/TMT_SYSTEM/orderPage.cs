﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TMT_SYSTEM
{
    public partial class orderPage : Form
    {
        
        SqlConnection sqconn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MPHO\Desktop\TMT_SYSTEM\TMT_SYSTEM\Database.mdf;Integrated Security=True");
        public string SchoolName { get; set; }

        public orderPage()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {


            
          //  sqconn.Open();
            //string SchoolName=  label3.Text.ToString();
            string name = SchoolName;
            int quantity;
            string golf = "GOLF";
            string V_Neck = "V-NECK";
            string T_Shirt = "T-SHIRT";
            string chino = "Chino";
            string cargo = "Cargo";
            string jeans = "Jeans";
            string hoody = "Hoody";
            string jacket = "Jacket";
            string Long_Sleeve = "Long-Sleeve";
            string small = "Small";
            string large = "Large";
            string medium = "Medium";
            string collection = "Not Collected yet";
            string delivery = "Not Deliveried yet";
            string blue = "Blue";
            string black = "Black";
            string white = "White";
            try
            {


                if (int.TryParse(txtQuantity.Text, out quantity))
                {

                    if (rbGolf.Checked && rbBlue.Checked && rbChino.Checked && rbSmall.Checked && rbHoody.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{ chino }','{ hoody }','{ large }', '{collection } ','{blue } ')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{ chino }','{ hoody }','{ large }', '{delivery } ','{ blue } ')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbGolf.Checked && rbBlack.Checked && rbCargo.Checked && rbmedium.Checked && rbJacket.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{cargo } ','{ jacket } ','{medium } ', '{collection } ','{ black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{cargo } ','{ jacket }','{ medium }', '{ delivery }','{black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbGolf.Checked && rbWhite.Checked && rbJeans.Checked && rbLarge.Checked && rbLSleeves.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{jeans}','{Long_Sleeve}','{large}', '{collection}','{white}')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ golf }','{jeans}','{Long_Sleeve}','{large}', '{delivery}','{white}')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    if (rbVNeck.Checked && rbBlue.Checked && rbChino.Checked && rbSmall.Checked && rbHoody.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ V_Neck }','{chino}','{hoody}','{ small}', '{collection}','{ blue}')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ V_Neck }','{chino} ','{hoody}','{ small}','{ delivery }','{ blue }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbVNeck.Checked && rbBlack.Checked && rbCargo.Checked && rbmedium.Checked && rbJacket.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ V_Neck }','{ cargo }','{ jacket }','{medium }',, '{ collection }','{ black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{ name }',{ quantity},'{ V_Neck }','{ cargo }','{ jacket }','{medium }', '{delivery }','{ black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbVNeck.Checked && rbWhite.Checked && rbJeans.Checked && rbLarge.Checked && rbLSleeves.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ V_Neck }','{jeans } ','{ Long_Sleeve } ','{large }', '{collection }','{white }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{ name }',{ quantity},'{ V_Neck }','{jeans } ','{ Long_Sleeve } ','{large }, '{delivery } ','{white } ')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    } 
                    if (rbTshirt.Checked && rbBlue.Checked && rbChino.Checked && rbSmall.Checked && rbHoody.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{ name }',{ quantity},'{ T_Shirt }','{chino } ','{ hoody } ','{ small }', '{collection } ','{blue} ')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{ name }',{ quantity},'{ T_Shirt }','{ chino }','{ hoody }','{small } ', '{delivery } ','{blue } ')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbTshirt.Checked && rbBlack.Checked && rbCargo.Checked && rbmedium.Checked && rbJacket.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order] values('{ name }',{ quantity},'{ T_Shirt }','{ cargo }','{ jacket }','{ medium }', '{ collection }','{ black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{ name }',{ quantity},'{ T_Shirt }','{ cargo }','{ jacket }','{ medium }', '{ delivery }','{ black }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }

                    }
                    else if (rbTshirt.Checked && rbWhite.Checked && rbJeans.Checked && rbLarge.Checked && rbLSleeves.Checked)
                    {
                        if (rbColection.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{name}',{quantity},'{T_Shirt}','{jeans} ','{Long_Sleeve}','{large}', '{ collection}','{ white}')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                        else if (rbDelivery.Checked)
                        {
                            SqlCommand sqlcomm = new SqlCommand($"INSERT INTO [Order]  values('{name}',{quantity},'{T_Shirt}','{jeans }','{ Long_Sleeve}','{ large }', '{delivery }','{ white }')", sqconn);
                            sqlcomm.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("ERROR: "+ex.Message);
            }
            sqconn.Close();
            MessageBox.Show("Order Successfully Made........")
        }

        private void rbColection_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbDelivery_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void grpJersSleeve_Enter(object sender, EventArgs e)
        {

        }

        private void lShirtSleeve_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
