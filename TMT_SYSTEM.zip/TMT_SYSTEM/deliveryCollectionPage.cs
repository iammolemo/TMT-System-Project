﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMT_SYSTEM
{
    public partial class deliveryCollectionPage : Form
    {
        public deliveryCollectionPage()
        {
            InitializeComponent();
        }

        private void btnCollection_Click(object sender, EventArgs e)
        {
            this.Hide();
            confirmOrderPage con = new confirmOrderPage();
            con.ShowDialog();
   
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            this.Hide();
            designPage d = new designPage();
            d.ShowDialog();
        }

        private void btnDelivery_Click(object sender, EventArgs e)
        {
            this.Hide();
            deliveryPage delivery = new deliveryPage();
            delivery.ShowDialog();
        }
    }
}
