﻿namespace TMT_SYSTEM
{
    partial class maintainSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.maintainSupp = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnUpdateSupp = new System.Windows.Forms.Button();
            this.btnDeleteSupp = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.gridSupplier = new System.Windows.Forms.DataGridView();
            this.btnInsert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // maintainSupp
            // 
            this.maintainSupp.AutoSize = true;
            this.maintainSupp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maintainSupp.Location = new System.Drawing.Point(356, 35);
            this.maintainSupp.Name = "maintainSupp";
            this.maintainSupp.Size = new System.Drawing.Size(154, 18);
            this.maintainSupp.TabIndex = 0;
            this.maintainSupp.Text = "MAINTAIN SUPPLIERS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "SEARCH:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(80, 87);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 20);
            this.txtSearch.TabIndex = 2;
            // 
            // btnUpdateSupp
            // 
            this.btnUpdateSupp.Location = new System.Drawing.Point(23, 219);
            this.btnUpdateSupp.Name = "btnUpdateSupp";
            this.btnUpdateSupp.Size = new System.Drawing.Size(157, 36);
            this.btnUpdateSupp.TabIndex = 3;
            this.btnUpdateSupp.Text = "UPDATE SELECTED SUPPLIER";
            this.btnUpdateSupp.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSupp
            // 
            this.btnDeleteSupp.Location = new System.Drawing.Point(23, 289);
            this.btnDeleteSupp.Name = "btnDeleteSupp";
            this.btnDeleteSupp.Size = new System.Drawing.Size(157, 40);
            this.btnDeleteSupp.TabIndex = 4;
            this.btnDeleteSupp.Text = "DELETE SELECTED SUPPLIER";
            this.btnDeleteSupp.UseVisualStyleBackColor = true;
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(12, 450);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(124, 32);
            this.btnPrev.TabIndex = 5;
            this.btnPrev.Text = "PREVIOUS PAGE";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnHome
            // 
            this.btnHome.Location = new System.Drawing.Point(670, 450);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(118, 32);
            this.btnHome.TabIndex = 6;
            this.btnHome.Text = "HOME PAGE";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // gridSupplier
            // 
            this.gridSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSupplier.Location = new System.Drawing.Point(229, 90);
            this.gridSupplier.Name = "gridSupplier";
            this.gridSupplier.Size = new System.Drawing.Size(532, 325);
            this.gridSupplier.TabIndex = 7;
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(23, 167);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(157, 34);
            this.btnInsert.TabIndex = 8;
            this.btnInsert.Text = "ADD NEW SUPLLIER";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // maintainSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 485);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.gridSupplier);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.btnDeleteSupp);
            this.Controls.Add(this.btnUpdateSupp);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.maintainSupp);
            this.Name = "maintainSupplier";
            this.Text = "maintainSupplier";
            this.Load += new System.EventHandler(this.maintainSupplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridSupplier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label maintainSupp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnUpdateSupp;
        private System.Windows.Forms.Button btnDeleteSupp;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.DataGridView gridSupplier;
        private System.Windows.Forms.Button btnInsert;
    }
}