﻿namespace TMT_SYSTEM
{
    partial class deliveryPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblConfirmAdd = new System.Windows.Forms.Label();
            this.lblOne = new System.Windows.Forms.Label();
            this.lblTwo = new System.Windows.Forms.Label();
            this.lblProvince = new System.Windows.Forms.Label();
            this.lblPCode = new System.Windows.Forms.Label();
            this.lblLine1 = new System.Windows.Forms.Label();
            this.lblLine2 = new System.Windows.Forms.Label();
            this.lblProv = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.grpschoolAdd = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.okBtn = new System.Windows.Forms.Button();
            this.lblError = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.grpContactNo = new System.Windows.Forms.GroupBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.btnYes = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.grpschoolAdd.SuspendLayout();
            this.grpContactNo.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(282, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "DELIVERY";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(116, 97);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(144, 13);
            this.lblEmail.TabIndex = 1;
            this.lblEmail.Text = "SCHOOL EMAIL ADDRESS:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(287, 90);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(111, 20);
            this.txtEmail.TabIndex = 2;
            // 
            // lblConfirmAdd
            // 
            this.lblConfirmAdd.AutoSize = true;
            this.lblConfirmAdd.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmAdd.Location = new System.Drawing.Point(70, 197);
            this.lblConfirmAdd.Name = "lblConfirmAdd";
            this.lblConfirmAdd.Size = new System.Drawing.Size(376, 14);
            this.lblConfirmAdd.TabIndex = 3;
            this.lblConfirmAdd.Text = "PLEASE CONFIRM YOUR SCHOOL\'S ADDRES AND CONTACT NUMBERS:";
            this.lblConfirmAdd.Visible = false;
            // 
            // lblOne
            // 
            this.lblOne.AutoSize = true;
            this.lblOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOne.Location = new System.Drawing.Point(15, 30);
            this.lblOne.Name = "lblOne";
            this.lblOne.Size = new System.Drawing.Size(80, 13);
            this.lblOne.TabIndex = 17;
            this.lblOne.Text = "Address Line 1:";
            this.lblOne.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblTwo
            // 
            this.lblTwo.AutoSize = true;
            this.lblTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTwo.Location = new System.Drawing.Point(15, 62);
            this.lblTwo.Name = "lblTwo";
            this.lblTwo.Size = new System.Drawing.Size(80, 13);
            this.lblTwo.TabIndex = 18;
            this.lblTwo.Text = "Address Line 2:";
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProvince.Location = new System.Drawing.Point(15, 91);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(52, 13);
            this.lblProvince.TabIndex = 19;
            this.lblProvince.Text = "Province:";
            this.lblProvince.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblPCode
            // 
            this.lblPCode.AutoSize = true;
            this.lblPCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPCode.Location = new System.Drawing.Point(15, 123);
            this.lblPCode.Name = "lblPCode";
            this.lblPCode.Size = new System.Drawing.Size(66, 13);
            this.lblPCode.TabIndex = 20;
            this.lblPCode.Text = "Postal code:";
            // 
            // lblLine1
            // 
            this.lblLine1.AutoSize = true;
            this.lblLine1.Location = new System.Drawing.Point(256, 30);
            this.lblLine1.Name = "lblLine1";
            this.lblLine1.Size = new System.Drawing.Size(16, 13);
            this.lblLine1.TabIndex = 21;
            this.lblLine1.Text = "...";
            // 
            // lblLine2
            // 
            this.lblLine2.AutoSize = true;
            this.lblLine2.Location = new System.Drawing.Point(256, 62);
            this.lblLine2.Name = "lblLine2";
            this.lblLine2.Size = new System.Drawing.Size(16, 13);
            this.lblLine2.TabIndex = 22;
            this.lblLine2.Text = "...";
            // 
            // lblProv
            // 
            this.lblProv.AutoSize = true;
            this.lblProv.Location = new System.Drawing.Point(256, 91);
            this.lblProv.Name = "lblProv";
            this.lblProv.Size = new System.Drawing.Size(16, 13);
            this.lblProv.TabIndex = 23;
            this.lblProv.Text = "...";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Location = new System.Drawing.Point(256, 123);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(19, 13);
            this.lblCode.TabIndex = 24;
            this.lblCode.Text = "....";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(215, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 13);
            this.label12.TabIndex = 25;
            // 
            // grpschoolAdd
            // 
            this.grpschoolAdd.Controls.Add(this.lblOne);
            this.grpschoolAdd.Controls.Add(this.lblCode);
            this.grpschoolAdd.Controls.Add(this.lblProv);
            this.grpschoolAdd.Controls.Add(this.lblTwo);
            this.grpschoolAdd.Controls.Add(this.lblLine2);
            this.grpschoolAdd.Controls.Add(this.label12);
            this.grpschoolAdd.Controls.Add(this.lblProvince);
            this.grpschoolAdd.Controls.Add(this.lblPCode);
            this.grpschoolAdd.Controls.Add(this.lblLine1);
            this.grpschoolAdd.Location = new System.Drawing.Point(93, 228);
            this.grpschoolAdd.Name = "grpschoolAdd";
            this.grpschoolAdd.Size = new System.Drawing.Size(373, 159);
            this.grpschoolAdd.TabIndex = 27;
            this.grpschoolAdd.TabStop = false;
            this.grpschoolAdd.Text = "SCHOOL ADDDRESS";
            this.grpschoolAdd.Visible = false;
            this.grpschoolAdd.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(207, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 28;
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(210, 151);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 29;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(51, 127);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(450, 13);
            this.lblError.TabIndex = 30;
            this.lblError.Text = "This email address does not exist. Please ensure that you\'ve entered the correct " +
    "email address";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(21, 532);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 27);
            this.btnBack.TabIndex = 31;
            this.btnBack.Text = "PREVIOUS PAGE";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // grpContactNo
            // 
            this.grpContactNo.Controls.Add(this.lblContactNo);
            this.grpContactNo.Controls.Add(this.lblPhone);
            this.grpContactNo.Location = new System.Drawing.Point(93, 403);
            this.grpContactNo.Name = "grpContactNo";
            this.grpContactNo.Size = new System.Drawing.Size(373, 67);
            this.grpContactNo.TabIndex = 32;
            this.grpContactNo.TabStop = false;
            this.grpContactNo.Text = "CONTACT DETAILS";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(32, 37);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(111, 13);
            this.lblPhone.TabIndex = 0;
            this.lblPhone.Text = "CONTACT NUMBER:";
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.Location = new System.Drawing.Point(256, 37);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(16, 13);
            this.lblContactNo.TabIndex = 1;
            this.lblContactNo.Text = "...";
            // 
            // btnYes
            // 
            this.btnYes.Location = new System.Drawing.Point(128, 490);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(79, 27);
            this.btnYes.TabIndex = 33;
            this.btnYes.Text = "YES";
            this.btnYes.UseVisualStyleBackColor = true;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // btnNo
            // 
            this.btnNo.Location = new System.Drawing.Point(316, 493);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(66, 24);
            this.btnNo.TabIndex = 34;
            this.btnNo.Text = "NO";
            this.btnNo.UseVisualStyleBackColor = true;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // deliveryPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 571);
            this.Controls.Add(this.btnNo);
            this.Controls.Add(this.btnYes);
            this.Controls.Add(this.grpContactNo);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.grpschoolAdd);
            this.Controls.Add(this.lblConfirmAdd);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.label1);
            this.Name = "deliveryPage";
            this.Text = "deliveryPage";
            this.grpschoolAdd.ResumeLayout(false);
            this.grpschoolAdd.PerformLayout();
            this.grpContactNo.ResumeLayout(false);
            this.grpContactNo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblConfirmAdd;
        private System.Windows.Forms.Label lblOne;
        private System.Windows.Forms.Label lblTwo;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.Label lblPCode;
        private System.Windows.Forms.Label lblLine1;
        private System.Windows.Forms.Label lblLine2;
        private System.Windows.Forms.Label lblProv;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox grpschoolAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.GroupBox grpContactNo;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.Button btnNo;
    }
}