﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TMT_SYSTEM
{
    public partial class Form1 : Form
    {
        string conString = @"Data Source=DESKTOP-DQF9S0M;Initial Catalog=TMT;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader myReader;
        public Form1()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = false;
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            /*txtUsername.BackColor = Color.White;
            panel3.BackColor = Color.White;
            txtPassWord.BackColor = SystemColors.Control;
            panel4.BackColor = SystemColors.Control;*/
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            /*txtUsername.BackColor = SystemColors.Control;
            panel3.BackColor = SystemColors.Control;
            txtPassWord.BackColor = Color.White;
            panel4.BackColor = Color.White;*/
        }

        private void txtPassWord_TextChanged(object sender, EventArgs e)
        {
            /*txtUsername.BackColor = SystemColors.Control;
            panel3.BackColor = SystemColors.Control;
            txtPassWord.BackColor = Color.White;
            panel4.BackColor = Color.White;*/
        }

        private void txtUsername_Click(object sender, EventArgs e)
        {
            txtUsername.BackColor = Color.White;
            panel3.BackColor = Color.White;
            txtPassword.BackColor = SystemColors.Control;
            panel4.BackColor = SystemColors.Control;
        }

        private void txtPassWord_Click(object sender, EventArgs e)
        {
            txtUsername.BackColor = SystemColors.Control;
            panel3.BackColor = SystemColors.Control;
            txtPassword.BackColor = Color.White;
            panel4.BackColor = Color.White;
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            this.Hide();
            createAccPage f2 = new createAccPage();
            f2.ShowDialog();
        }

        public string SchoolName { get; set; }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(conString);
                con.Open();
                if (txtUsername.Text != "" && txtPassword.Text != "")
                {

                    string pass = txtPassword.Text;
                    string userNameAdmin = txtUsername.Text.ToLower();

                    string query = "SELECT * from [SCHOOL] WHERE email ='" + txtUsername.Text + "' AND Password ='" + pass + "'";

                    if (txtPassword.Text == pass)
                    {
                        cmd = new SqlCommand(query, con);
                        myReader = cmd.ExecuteReader();
                        if (myReader.HasRows)
                        {
                            orderPage order = new orderPage();
                            order.Show(); //show the mainain page
                            myReader.Close();
                            this.Hide();

                        }
                        else
                        {
                            MessageBox.Show("Sorry, Username and password you entered doesn't belong to an account. Please double-check Your details and try again.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("The Username or Password is empty", "Information");
                }
                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_load(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            supplierPage f4 = new supplierPage();
            f4.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnEmpLogin_Click(object sender, EventArgs e)
        {
            employeePage emp = new employeePage();
            emp.ShowDialog();

        }
    }
}

