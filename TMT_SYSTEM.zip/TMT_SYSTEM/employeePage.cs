﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMT_SYSTEM
{
    public partial class employeePage : Form
    {
        public employeePage()
        {
            InitializeComponent();
        }

        private void btnEmplLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeeLogin login = new employeeLogin();
            login.ShowDialog();
        }

        private void btnEmplRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            registerEmployee register = new registerEmployee();
            register.ShowDialog();
        }
    }
}
