﻿namespace TMT_SYSTEM
{
    partial class employeePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEmplLogin = new System.Windows.Forms.Button();
            this.btnEmplRegister = new System.Windows.Forms.Button();
            this.lblEmp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEmplLogin
            // 
            this.btnEmplLogin.Location = new System.Drawing.Point(184, 94);
            this.btnEmplLogin.Name = "btnEmplLogin";
            this.btnEmplLogin.Size = new System.Drawing.Size(151, 41);
            this.btnEmplLogin.TabIndex = 0;
            this.btnEmplLogin.Text = "LOGIN AS EMPLOYEE";
            this.btnEmplLogin.UseVisualStyleBackColor = true;
            this.btnEmplLogin.Click += new System.EventHandler(this.btnEmplLogin_Click);
            // 
            // btnEmplRegister
            // 
            this.btnEmplRegister.Location = new System.Drawing.Point(184, 162);
            this.btnEmplRegister.Name = "btnEmplRegister";
            this.btnEmplRegister.Size = new System.Drawing.Size(151, 45);
            this.btnEmplRegister.TabIndex = 1;
            this.btnEmplRegister.Text = "REGISTER AS NEW EMPLOYEE";
            this.btnEmplRegister.UseVisualStyleBackColor = true;
            this.btnEmplRegister.Click += new System.EventHandler(this.btnEmplRegister_Click);
            // 
            // lblEmp
            // 
            this.lblEmp.AutoSize = true;
            this.lblEmp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmp.Location = new System.Drawing.Point(201, 31);
            this.lblEmp.Name = "lblEmp";
            this.lblEmp.Size = new System.Drawing.Size(83, 18);
            this.lblEmp.TabIndex = 2;
            this.lblEmp.Text = "EMPLOYEE";
            // 
            // employeePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 323);
            this.Controls.Add(this.lblEmp);
            this.Controls.Add(this.btnEmplRegister);
            this.Controls.Add(this.btnEmplLogin);
            this.Name = "employeePage";
            this.Text = "employeePage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEmplLogin;
        private System.Windows.Forms.Button btnEmplRegister;
        private System.Windows.Forms.Label lblEmp;
    }
}