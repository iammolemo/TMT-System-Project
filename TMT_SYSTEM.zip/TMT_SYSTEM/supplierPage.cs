﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TMT_SYSTEM
{
    public partial class supplierPage : Form
    {
        SqlConnection sqlConn1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MPHO\Desktop\TMT_SYSTEM\TMT_SYSTEM\Database.mdf;Integrated Security=True");
        SqlCommand comma1, comma2;
        SqlDataReader dr1, dr2;
        public supplierPage()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            string SupplierName = txtSupplierName.Text;
            string MaterialName = txtSMaterial.Text;
            int quantity = int.Parse(txtQSupplied.Text);
            comma1 = new SqlCommand($"INSERT INTO [Supplier] values('{SupplierName}','{MaterialName}',{quantity})", sqlConn1);
            comma2 = new SqlCommand($"INSERT INTO [Material] values('{MaterialName}',{quantity})", sqlConn1);
            comma1.ExecuteNonQuery();
            comma2.ExecuteNonQuery();

            sqlConn1.Open();
            /*while (dr1.Read() && dr2.Read())
            {
                if(dr1.ToString() != SupplierName || dr2.ToString() != MaterialName)
                {
                    comma1 = new SqlCommand($"INSERT INTO [Supplier] values('{SupplierName}','{MaterialName}',{quantity})", sqlConn1);
                    comma2 = new SqlCommand($"INSERT INTO [Material] values('{MaterialName}',{quantity})", sqlConn1);
                    comma1.ExecuteNonQuery();
                    comma2.ExecuteNonQuery();
                    if(dr1.ToString() == SupplierName)
                    {
                        MessageBox.Show("You already added that Record......");
                        break;
                    }
                    if(dr2.ToString() == MaterialName)
                    {
                        comma2 = new SqlCommand($"UPDATE [Material] SET Quantity = Quantity + {quantity}", sqlConn1);
                        comma2.ExecuteNonQuery();
                        break;
                    }
                }
            }*/

            sqlConn1.Close();
            MessageBox.Show("You Have Maintained the Records.....");
        }
    }
}
