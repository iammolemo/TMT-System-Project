﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TMT_SYSTEM
{
    public partial class createAccPage : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        string conString= "Data Source=DESKTOP-DQF9S0M;Initial Catalog=TMT;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        public createAccPage()
        {
            InitializeComponent();
        }

        private void txtMail_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        public static bool validatePassword(string pass, string confirmPass)
        {

            if (pass != "" && confirmPass != "")
            {
                if (pass.ToString().Trim().ToLower() == confirmPass.ToString().Trim().ToLower())
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("The Entererd Passwords do not match, Please Check and ensure that they do in order to proceed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);  //showing the error message if password and confirm password doesn't match  
                }

            }
            else
            {
                MessageBox.Show("Please fill all the details required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);  //showing the error message if any fields is empty  
            }
            return false;

        }

        private void clearAll()
        {
            txtSName.Clear();
            txtSEmail.Clear();
            txtNumber.Clear();
            txtAddress1.Clear();
            txtAddress2.Clear();
            txtProvince.Clear();
            txtPCode.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);


            try
            {

                bool confirmPassword = validatePassword(txtPassword.Text.ToString(), txtConfirmPassword.Text.ToString());
                if (confirmPassword == true && (txtSName.Text != "" || txtSEmail.Text != "" || txtNumber.Text != "" || txtAddress1.Text != " " || txtProvince.Text != " " || txtPCode.Text != " "))
                {
                    if (con.State != ConnectionState.Open)
                        con.Open();

                    string sql = @"INSERT INTO [SCHOOL](schoolName,Email,cellNo,password,address1,address2,province,pcode) VALUES(@schoolName,@email,@cellNo, @password,@address1,@address2,@province,@pcode)";

                    string pass = txtConfirmPassword.Text;
                    cmd = new SqlCommand(sql, con);

                    cmd.Parameters.AddWithValue("@schoolName", txtSName.Text);
                    cmd.Parameters.AddWithValue("@email", txtSEmail.Text);
                    cmd.Parameters.AddWithValue("@cellNo", txtNumber.Text);
                    cmd.Parameters.AddWithValue("@password", pass);
                    cmd.Parameters.AddWithValue("@address1", txtAddress1.Text);
                    cmd.Parameters.AddWithValue("@address1", txtAddress1.Text);
                    cmd.Parameters.AddWithValue("@province", txtProvince.Text);
                    cmd.Parameters.AddWithValue("@pcode", txtPCode.Text);


                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Your account has been successfully registered.", "New user inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clearAll();


                    con.Close();
                }
                else
                {
                    if (confirmPassword == true)
                        MessageBox.Show("Please fill all the the spaces, all details are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch
            {
                MessageBox.Show("This email address is already taken", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSEmail.Clear();
                txtSEmail.Focus();
            }
        }
    }
}



        
    

