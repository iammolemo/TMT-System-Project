﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMT_SYSTEM
{
    public partial class managerLogin : Form
    {
        public managerLogin()
        {
            InitializeComponent();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeeLogin login = new employeeLogin();
            login.ShowDialog();
        }
    }
}
