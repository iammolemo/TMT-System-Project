﻿namespace TMT_SYSTEM
{
    partial class orderPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCreate = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.grpBoxJersey = new System.Windows.Forms.GroupBox();
            this.rbLSleeves = new System.Windows.Forms.RadioButton();
            this.rbJacket = new System.Windows.Forms.RadioButton();
            this.rbHoody = new System.Windows.Forms.RadioButton();
            this.grpBoxTrouser = new System.Windows.Forms.GroupBox();
            this.rbJeans = new System.Windows.Forms.RadioButton();
            this.rbCargo = new System.Windows.Forms.RadioButton();
            this.rbChino = new System.Windows.Forms.RadioButton();
            this.grpBoxShirt = new System.Windows.Forms.GroupBox();
            this.rbTshirt = new System.Windows.Forms.RadioButton();
            this.rbVNeck = new System.Windows.Forms.RadioButton();
            this.rbGolf = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.lblShirtQuant = new System.Windows.Forms.Label();
            this.lblTrouser = new System.Windows.Forms.Label();
            this.lblJersey = new System.Windows.Forms.Label();
            this.txtJerseyQuant = new System.Windows.Forms.TextBox();
            this.txtTrousQuant = new System.Windows.Forms.TextBox();
            this.txtShirtQuant = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpShirtSize = new System.Windows.Forms.GroupBox();
            this.grpShirtSleeve = new System.Windows.Forms.GroupBox();
            this.grpTrousSize = new System.Windows.Forms.GroupBox();
            this.grpTrousLength = new System.Windows.Forms.GroupBox();
            this.grpJerseySize = new System.Windows.Forms.GroupBox();
            this.grpJerseySleeve = new System.Windows.Forms.GroupBox();
            this.sShirt = new System.Windows.Forms.RadioButton();
            this.mShirt = new System.Windows.Forms.RadioButton();
            this.sShirtSleeve = new System.Windows.Forms.RadioButton();
            this.lShirtSleeve = new System.Windows.Forms.RadioButton();
            this.sTrous = new System.Windows.Forms.RadioButton();
            this.mTrous = new System.Windows.Forms.RadioButton();
            this.lTrousLeng = new System.Windows.Forms.RadioButton();
            this.sTrousLeng = new System.Windows.Forms.RadioButton();
            this.sJersey = new System.Windows.Forms.RadioButton();
            this.mJersey = new System.Windows.Forms.RadioButton();
            this.sJerseySleeve = new System.Windows.Forms.RadioButton();
            this.lJerseySleeve = new System.Windows.Forms.RadioButton();
            this.lShirt = new System.Windows.Forms.RadioButton();
            this.lTrous = new System.Windows.Forms.RadioButton();
            this.lJersey = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grpBoxJersey.SuspendLayout();
            this.grpBoxTrouser.SuspendLayout();
            this.grpBoxShirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpShirtSize.SuspendLayout();
            this.grpShirtSleeve.SuspendLayout();
            this.grpTrousSize.SuspendLayout();
            this.grpTrousLength.SuspendLayout();
            this.grpJerseySize.SuspendLayout();
            this.grpJerseySleeve.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(851, 100);
            this.panel1.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(811, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 40);
            this.button4.TabIndex = 2;
            this.button4.Text = "X";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(147, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "TAILOR MADE TAILORS";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.btnCreate);
            this.panel3.Controls.Add(this.groupBox6);
            this.panel3.Controls.Add(this.grpBoxJersey);
            this.panel3.Controls.Add(this.grpBoxTrouser);
            this.panel3.Controls.Add(this.grpBoxShirt);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(851, 437);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(315, 396);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(126, 38);
            this.btnCreate.TabIndex = 9;
            this.btnCreate.Text = "PROCEED TO DESIGN";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(300, 220);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(0, 0);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "QUANTITY";
            // 
            // grpBoxJersey
            // 
            this.grpBoxJersey.BackColor = System.Drawing.Color.Silver;
            this.grpBoxJersey.Controls.Add(this.grpJerseySize);
            this.grpBoxJersey.Controls.Add(this.grpJerseySleeve);
            this.grpBoxJersey.Controls.Add(this.label7);
            this.grpBoxJersey.Controls.Add(this.label8);
            this.grpBoxJersey.Controls.Add(this.txtJerseyQuant);
            this.grpBoxJersey.Controls.Add(this.lblJersey);
            this.grpBoxJersey.Controls.Add(this.rbLSleeves);
            this.grpBoxJersey.Controls.Add(this.rbJacket);
            this.grpBoxJersey.Controls.Add(this.rbHoody);
            this.grpBoxJersey.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.grpBoxJersey.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxJersey.Location = new System.Drawing.Point(545, 53);
            this.grpBoxJersey.Name = "grpBoxJersey";
            this.grpBoxJersey.Size = new System.Drawing.Size(252, 331);
            this.grpBoxJersey.TabIndex = 4;
            this.grpBoxJersey.TabStop = false;
            this.grpBoxJersey.Text = "JERSEY";
            // 
            // rbLSleeves
            // 
            this.rbLSleeves.AutoSize = true;
            this.rbLSleeves.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLSleeves.Location = new System.Drawing.Point(6, 79);
            this.rbLSleeves.Name = "rbLSleeves";
            this.rbLSleeves.Size = new System.Drawing.Size(131, 22);
            this.rbLSleeves.TabIndex = 3;
            this.rbLSleeves.TabStop = true;
            this.rbLSleeves.Text = "LONG-SLEEVE";
            this.rbLSleeves.UseVisualStyleBackColor = true;
            // 
            // rbJacket
            // 
            this.rbJacket.AutoSize = true;
            this.rbJacket.Location = new System.Drawing.Point(6, 51);
            this.rbJacket.Name = "rbJacket";
            this.rbJacket.Size = new System.Drawing.Size(87, 24);
            this.rbJacket.TabIndex = 2;
            this.rbJacket.TabStop = true;
            this.rbJacket.Text = "JACKET";
            this.rbJacket.UseVisualStyleBackColor = true;
            // 
            // rbHoody
            // 
            this.rbHoody.AutoSize = true;
            this.rbHoody.Location = new System.Drawing.Point(6, 25);
            this.rbHoody.Name = "rbHoody";
            this.rbHoody.Size = new System.Drawing.Size(86, 24);
            this.rbHoody.TabIndex = 1;
            this.rbHoody.TabStop = true;
            this.rbHoody.Text = "HOODY";
            this.rbHoody.UseVisualStyleBackColor = true;
            // 
            // grpBoxTrouser
            // 
            this.grpBoxTrouser.Controls.Add(this.grpTrousSize);
            this.grpBoxTrouser.Controls.Add(this.grpTrousLength);
            this.grpBoxTrouser.Controls.Add(this.label6);
            this.grpBoxTrouser.Controls.Add(this.label5);
            this.grpBoxTrouser.Controls.Add(this.txtTrousQuant);
            this.grpBoxTrouser.Controls.Add(this.lblTrouser);
            this.grpBoxTrouser.Controls.Add(this.rbJeans);
            this.grpBoxTrouser.Controls.Add(this.rbCargo);
            this.grpBoxTrouser.Controls.Add(this.rbChino);
            this.grpBoxTrouser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxTrouser.Location = new System.Drawing.Point(269, 53);
            this.grpBoxTrouser.Name = "grpBoxTrouser";
            this.grpBoxTrouser.Size = new System.Drawing.Size(270, 337);
            this.grpBoxTrouser.TabIndex = 3;
            this.grpBoxTrouser.TabStop = false;
            this.grpBoxTrouser.Text = "TROUSER";
            // 
            // rbJeans
            // 
            this.rbJeans.AutoSize = true;
            this.rbJeans.Location = new System.Drawing.Point(6, 79);
            this.rbJeans.Name = "rbJeans";
            this.rbJeans.Size = new System.Drawing.Size(79, 24);
            this.rbJeans.TabIndex = 3;
            this.rbJeans.TabStop = true;
            this.rbJeans.Text = "JEANS";
            this.rbJeans.UseVisualStyleBackColor = true;
            // 
            // rbCargo
            // 
            this.rbCargo.AutoSize = true;
            this.rbCargo.Location = new System.Drawing.Point(6, 51);
            this.rbCargo.Name = "rbCargo";
            this.rbCargo.Size = new System.Drawing.Size(86, 24);
            this.rbCargo.TabIndex = 2;
            this.rbCargo.TabStop = true;
            this.rbCargo.Text = "CARGO";
            this.rbCargo.UseVisualStyleBackColor = true;
            // 
            // rbChino
            // 
            this.rbChino.AutoSize = true;
            this.rbChino.Location = new System.Drawing.Point(6, 25);
            this.rbChino.Name = "rbChino";
            this.rbChino.Size = new System.Drawing.Size(78, 24);
            this.rbChino.TabIndex = 1;
            this.rbChino.TabStop = true;
            this.rbChino.Text = "CHINO";
            this.rbChino.UseVisualStyleBackColor = true;
            // 
            // grpBoxShirt
            // 
            this.grpBoxShirt.Controls.Add(this.grpShirtSleeve);
            this.grpBoxShirt.Controls.Add(this.grpShirtSize);
            this.grpBoxShirt.Controls.Add(this.txtShirtQuant);
            this.grpBoxShirt.Controls.Add(this.rbTshirt);
            this.grpBoxShirt.Controls.Add(this.label4);
            this.grpBoxShirt.Controls.Add(this.lblShirtQuant);
            this.grpBoxShirt.Controls.Add(this.rbVNeck);
            this.grpBoxShirt.Controls.Add(this.rbGolf);
            this.grpBoxShirt.Controls.Add(this.label3);
            this.grpBoxShirt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxShirt.Location = new System.Drawing.Point(6, 53);
            this.grpBoxShirt.Name = "grpBoxShirt";
            this.grpBoxShirt.Size = new System.Drawing.Size(257, 337);
            this.grpBoxShirt.TabIndex = 2;
            this.grpBoxShirt.TabStop = false;
            this.grpBoxShirt.Text = "SHIRT";
            // 
            // rbTshirt
            // 
            this.rbTshirt.AutoSize = true;
            this.rbTshirt.Location = new System.Drawing.Point(6, 87);
            this.rbTshirt.Name = "rbTshirt";
            this.rbTshirt.Size = new System.Drawing.Size(74, 24);
            this.rbTshirt.TabIndex = 2;
            this.rbTshirt.TabStop = true;
            this.rbTshirt.Text = "T-Shirt";
            this.rbTshirt.UseVisualStyleBackColor = true;
            // 
            // rbVNeck
            // 
            this.rbVNeck.AutoSize = true;
            this.rbVNeck.Location = new System.Drawing.Point(6, 57);
            this.rbVNeck.Name = "rbVNeck";
            this.rbVNeck.Size = new System.Drawing.Size(86, 24);
            this.rbVNeck.TabIndex = 1;
            this.rbVNeck.TabStop = true;
            this.rbVNeck.Text = "V-NECK";
            this.rbVNeck.UseVisualStyleBackColor = true;
            // 
            // rbGolf
            // 
            this.rbGolf.AutoSize = true;
            this.rbGolf.Location = new System.Drawing.Point(6, 25);
            this.rbGolf.Name = "rbGolf";
            this.rbGolf.Size = new System.Drawing.Size(71, 24);
            this.rbGolf.TabIndex = 0;
            this.rbGolf.TabStop = true;
            this.rbGolf.Text = "GOLF";
            this.rbGolf.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label2.Location = new System.Drawing.Point(329, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "PLACE AN ORDER";
            // 
            // lblShirtQuant
            // 
            this.lblShirtQuant.Location = new System.Drawing.Point(6, 129);
            this.lblShirtQuant.Name = "lblShirtQuant";
            this.lblShirtQuant.Size = new System.Drawing.Size(74, 23);
            this.lblShirtQuant.TabIndex = 13;
            this.lblShirtQuant.Text = "Quantity";
            // 
            // lblTrouser
            // 
            this.lblTrouser.AutoSize = true;
            this.lblTrouser.Location = new System.Drawing.Point(6, 126);
            this.lblTrouser.Name = "lblTrouser";
            this.lblTrouser.Size = new System.Drawing.Size(68, 20);
            this.lblTrouser.TabIndex = 14;
            this.lblTrouser.Text = "Quantity";
            // 
            // lblJersey
            // 
            this.lblJersey.AutoSize = true;
            this.lblJersey.Location = new System.Drawing.Point(6, 129);
            this.lblJersey.Name = "lblJersey";
            this.lblJersey.Size = new System.Drawing.Size(68, 20);
            this.lblJersey.TabIndex = 15;
            this.lblJersey.Text = "Quantity";
            // 
            // txtJerseyQuant
            // 
            this.txtJerseyQuant.Location = new System.Drawing.Point(87, 126);
            this.txtJerseyQuant.Name = "txtJerseyQuant";
            this.txtJerseyQuant.Size = new System.Drawing.Size(100, 26);
            this.txtJerseyQuant.TabIndex = 4;
            // 
            // txtTrousQuant
            // 
            this.txtTrousQuant.Location = new System.Drawing.Point(87, 126);
            this.txtTrousQuant.Name = "txtTrousQuant";
            this.txtTrousQuant.Size = new System.Drawing.Size(100, 26);
            this.txtTrousQuant.TabIndex = 15;
            // 
            // txtShirtQuant
            // 
            this.txtShirtQuant.Location = new System.Drawing.Point(89, 126);
            this.txtShirtQuant.Name = "txtShirtQuant";
            this.txtShirtQuant.Size = new System.Drawing.Size(100, 26);
            this.txtShirtQuant.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "SIZE:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "SLEEVES:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "SIZE:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 281);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "LENGTH:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "SIZE:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 281);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "SLEEVES:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Image = global::TMT_SYSTEM.Properties.Resources.download;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // grpShirtSize
            // 
            this.grpShirtSize.Controls.Add(this.sShirt);
            this.grpShirtSize.Controls.Add(this.lShirt);
            this.grpShirtSize.Controls.Add(this.mShirt);
            this.grpShirtSize.Location = new System.Drawing.Point(81, 167);
            this.grpShirtSize.Name = "grpShirtSize";
            this.grpShirtSize.Size = new System.Drawing.Size(168, 100);
            this.grpShirtSize.TabIndex = 22;
            this.grpShirtSize.TabStop = false;
            // 
            // grpShirtSleeve
            // 
            this.grpShirtSleeve.Controls.Add(this.sShirtSleeve);
            this.grpShirtSleeve.Controls.Add(this.lShirtSleeve);
            this.grpShirtSleeve.Location = new System.Drawing.Point(89, 266);
            this.grpShirtSleeve.Name = "grpShirtSleeve";
            this.grpShirtSleeve.Size = new System.Drawing.Size(160, 65);
            this.grpShirtSleeve.TabIndex = 23;
            this.grpShirtSleeve.TabStop = false;
            // 
            // grpTrousSize
            // 
            this.grpTrousSize.Controls.Add(this.lTrous);
            this.grpTrousSize.Controls.Add(this.sTrous);
            this.grpTrousSize.Controls.Add(this.mTrous);
            this.grpTrousSize.Location = new System.Drawing.Point(86, 167);
            this.grpTrousSize.Name = "grpTrousSize";
            this.grpTrousSize.Size = new System.Drawing.Size(178, 92);
            this.grpTrousSize.TabIndex = 23;
            this.grpTrousSize.TabStop = false;
            // 
            // grpTrousLength
            // 
            this.grpTrousLength.Controls.Add(this.lTrousLeng);
            this.grpTrousLength.Controls.Add(this.sTrousLeng);
            this.grpTrousLength.Location = new System.Drawing.Point(87, 271);
            this.grpTrousLength.Name = "grpTrousLength";
            this.grpTrousLength.Size = new System.Drawing.Size(177, 60);
            this.grpTrousLength.TabIndex = 23;
            this.grpTrousLength.TabStop = false;
            // 
            // grpJerseySize
            // 
            this.grpJerseySize.Controls.Add(this.lJersey);
            this.grpJerseySize.Controls.Add(this.sJersey);
            this.grpJerseySize.Controls.Add(this.mJersey);
            this.grpJerseySize.Location = new System.Drawing.Point(87, 167);
            this.grpJerseySize.Name = "grpJerseySize";
            this.grpJerseySize.Size = new System.Drawing.Size(159, 93);
            this.grpJerseySize.TabIndex = 23;
            this.grpJerseySize.TabStop = false;
            // 
            // grpJerseySleeve
            // 
            this.grpJerseySleeve.Controls.Add(this.sJerseySleeve);
            this.grpJerseySleeve.Controls.Add(this.lJerseySleeve);
            this.grpJerseySleeve.Location = new System.Drawing.Point(87, 266);
            this.grpJerseySleeve.Name = "grpJerseySleeve";
            this.grpJerseySleeve.Size = new System.Drawing.Size(159, 59);
            this.grpJerseySleeve.TabIndex = 23;
            this.grpJerseySleeve.TabStop = false;
            this.grpJerseySleeve.Enter += new System.EventHandler(this.grpJersSleeve_Enter);
            // 
            // sShirt
            // 
            this.sShirt.AutoCheck = false;
            this.sShirt.Location = new System.Drawing.Point(6, 20);
            this.sShirt.Name = "sShirt";
            this.sShirt.Size = new System.Drawing.Size(123, 20);
            this.sShirt.TabIndex = 0;
            this.sShirt.TabStop = true;
            this.sShirt.Text = "Small";
            this.sShirt.UseVisualStyleBackColor = true;
            // 
            // mShirt
            // 
            this.mShirt.AutoCheck = false;
            this.mShirt.Location = new System.Drawing.Point(6, 46);
            this.mShirt.Name = "mShirt";
            this.mShirt.Size = new System.Drawing.Size(114, 20);
            this.mShirt.TabIndex = 23;
            this.mShirt.TabStop = true;
            this.mShirt.Text = "Medium";
            this.mShirt.UseVisualStyleBackColor = true;
            // 
            // sShirtSleeve
            // 
            this.sShirtSleeve.AutoCheck = false;
            this.sShirtSleeve.Location = new System.Drawing.Point(9, 15);
            this.sShirtSleeve.Name = "sShirtSleeve";
            this.sShirtSleeve.Size = new System.Drawing.Size(79, 20);
            this.sShirtSleeve.TabIndex = 24;
            this.sShirtSleeve.TabStop = true;
            this.sShirtSleeve.Text = "Short";
            this.sShirtSleeve.UseVisualStyleBackColor = true;
            // 
            // lShirtSleeve
            // 
            this.lShirtSleeve.AutoCheck = false;
            this.lShirtSleeve.Location = new System.Drawing.Point(9, 35);
            this.lShirtSleeve.Name = "lShirtSleeve";
            this.lShirtSleeve.Size = new System.Drawing.Size(79, 24);
            this.lShirtSleeve.TabIndex = 25;
            this.lShirtSleeve.TabStop = true;
            this.lShirtSleeve.Text = "Long";
            this.lShirtSleeve.UseVisualStyleBackColor = true;
            this.lShirtSleeve.CheckedChanged += new System.EventHandler(this.lShirtSleeve_CheckedChanged);
            // 
            // sTrous
            // 
            this.sTrous.AutoCheck = false;
            this.sTrous.Location = new System.Drawing.Point(6, 20);
            this.sTrous.Name = "sTrous";
            this.sTrous.Size = new System.Drawing.Size(88, 20);
            this.sTrous.TabIndex = 26;
            this.sTrous.TabStop = true;
            this.sTrous.Text = "Small";
            this.sTrous.UseVisualStyleBackColor = true;
            // 
            // mTrous
            // 
            this.mTrous.AutoCheck = false;
            this.mTrous.Location = new System.Drawing.Point(6, 46);
            this.mTrous.Name = "mTrous";
            this.mTrous.Size = new System.Drawing.Size(88, 20);
            this.mTrous.TabIndex = 27;
            this.mTrous.TabStop = true;
            this.mTrous.Text = "Medium";
            this.mTrous.UseVisualStyleBackColor = true;
            // 
            // lTrousLeng
            // 
            this.lTrousLeng.AutoCheck = false;
            this.lTrousLeng.Location = new System.Drawing.Point(6, 32);
            this.lTrousLeng.Name = "lTrousLeng";
            this.lTrousLeng.Size = new System.Drawing.Size(100, 22);
            this.lTrousLeng.TabIndex = 28;
            this.lTrousLeng.TabStop = true;
            this.lTrousLeng.Text = "Long";
            this.lTrousLeng.UseVisualStyleBackColor = true;
            // 
            // sTrousLeng
            // 
            this.sTrousLeng.AutoCheck = false;
            this.sTrousLeng.Location = new System.Drawing.Point(6, 9);
            this.sTrousLeng.Name = "sTrousLeng";
            this.sTrousLeng.Size = new System.Drawing.Size(95, 20);
            this.sTrousLeng.TabIndex = 29;
            this.sTrousLeng.TabStop = true;
            this.sTrousLeng.Text = "Short";
            this.sTrousLeng.UseVisualStyleBackColor = true;
            // 
            // sJersey
            // 
            this.sJersey.AutoCheck = false;
            this.sJersey.Location = new System.Drawing.Point(6, 12);
            this.sJersey.Name = "sJersey";
            this.sJersey.Size = new System.Drawing.Size(79, 20);
            this.sJersey.TabIndex = 30;
            this.sJersey.TabStop = true;
            this.sJersey.Text = "Small";
            this.sJersey.UseVisualStyleBackColor = true;
            // 
            // mJersey
            // 
            this.mJersey.AutoCheck = false;
            this.mJersey.Location = new System.Drawing.Point(6, 38);
            this.mJersey.Name = "mJersey";
            this.mJersey.Size = new System.Drawing.Size(94, 20);
            this.mJersey.TabIndex = 31;
            this.mJersey.TabStop = true;
            this.mJersey.Text = "Medium";
            this.mJersey.UseVisualStyleBackColor = true;
            // 
            // sJerseySleeve
            // 
            this.sJerseySleeve.AutoCheck = false;
            this.sJerseySleeve.Location = new System.Drawing.Point(6, 9);
            this.sJerseySleeve.Name = "sJerseySleeve";
            this.sJerseySleeve.Size = new System.Drawing.Size(79, 20);
            this.sJerseySleeve.TabIndex = 32;
            this.sJerseySleeve.TabStop = true;
            this.sJerseySleeve.Text = "Short";
            this.sJerseySleeve.UseVisualStyleBackColor = true;
            // 
            // lJerseySleeve
            // 
            this.lJerseySleeve.AutoCheck = false;
            this.lJerseySleeve.Location = new System.Drawing.Point(6, 29);
            this.lJerseySleeve.Name = "lJerseySleeve";
            this.lJerseySleeve.Size = new System.Drawing.Size(79, 26);
            this.lJerseySleeve.TabIndex = 33;
            this.lJerseySleeve.TabStop = true;
            this.lJerseySleeve.Text = "Long";
            this.lJerseySleeve.UseVisualStyleBackColor = true;
            // 
            // lShirt
            // 
            this.lShirt.AutoSize = true;
            this.lShirt.Location = new System.Drawing.Point(6, 69);
            this.lShirt.Name = "lShirt";
            this.lShirt.Size = new System.Drawing.Size(68, 24);
            this.lShirt.TabIndex = 24;
            this.lShirt.TabStop = true;
            this.lShirt.Text = "Large";
            this.lShirt.UseVisualStyleBackColor = true;
            // 
            // lTrous
            // 
            this.lTrous.Location = new System.Drawing.Point(6, 64);
            this.lTrous.Name = "lTrous";
            this.lTrous.Size = new System.Drawing.Size(128, 24);
            this.lTrous.TabIndex = 25;
            this.lTrous.TabStop = true;
            this.lTrous.Text = "Large";
            this.lTrous.UseVisualStyleBackColor = true;
            // 
            // lJersey
            // 
            this.lJersey.AutoSize = true;
            this.lJersey.Location = new System.Drawing.Point(6, 63);
            this.lJersey.Name = "lJersey";
            this.lJersey.Size = new System.Drawing.Size(68, 24);
            this.lJersey.TabIndex = 28;
            this.lJersey.TabStop = true;
            this.lJersey.Text = "Large";
            this.lJersey.UseVisualStyleBackColor = true;
            // 
            // orderPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(851, 537);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "orderPage";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.grpBoxJersey.ResumeLayout(false);
            this.grpBoxJersey.PerformLayout();
            this.grpBoxTrouser.ResumeLayout(false);
            this.grpBoxTrouser.PerformLayout();
            this.grpBoxShirt.ResumeLayout(false);
            this.grpBoxShirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpShirtSize.ResumeLayout(false);
            this.grpShirtSize.PerformLayout();
            this.grpShirtSleeve.ResumeLayout(false);
            this.grpTrousSize.ResumeLayout(false);
            this.grpTrousLength.ResumeLayout(false);
            this.grpJerseySize.ResumeLayout(false);
            this.grpJerseySize.PerformLayout();
            this.grpJerseySleeve.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox grpBoxJersey;
        private System.Windows.Forms.RadioButton rbLSleeves;
        private System.Windows.Forms.RadioButton rbJacket;
        private System.Windows.Forms.RadioButton rbHoody;
        private System.Windows.Forms.GroupBox grpBoxTrouser;
        private System.Windows.Forms.RadioButton rbJeans;
        private System.Windows.Forms.RadioButton rbCargo;
        private System.Windows.Forms.RadioButton rbChino;
        private System.Windows.Forms.GroupBox grpBoxShirt;
        private System.Windows.Forms.RadioButton rbTshirt;
        private System.Windows.Forms.RadioButton rbVNeck;
        private System.Windows.Forms.RadioButton rbGolf;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblJersey;
        private System.Windows.Forms.Label lblTrouser;
        private System.Windows.Forms.Label lblShirtQuant;
        private System.Windows.Forms.TextBox txtJerseyQuant;
        private System.Windows.Forms.TextBox txtTrousQuant;
        private System.Windows.Forms.TextBox txtShirtQuant;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpJerseySleeve;
        private System.Windows.Forms.GroupBox grpShirtSize;
        private System.Windows.Forms.GroupBox grpShirtSleeve;
        private System.Windows.Forms.GroupBox grpTrousSize;
        private System.Windows.Forms.GroupBox grpTrousLength;
        private System.Windows.Forms.GroupBox grpJerseySize;
        private System.Windows.Forms.RadioButton sJerseySleeve;
        private System.Windows.Forms.RadioButton lJerseySleeve;
        private System.Windows.Forms.RadioButton mJersey;
        private System.Windows.Forms.RadioButton sJersey;
        private System.Windows.Forms.RadioButton sTrousLeng;
        private System.Windows.Forms.RadioButton lTrousLeng;
        private System.Windows.Forms.RadioButton mTrous;
        private System.Windows.Forms.RadioButton sTrous;
        private System.Windows.Forms.RadioButton lShirtSleeve;
        private System.Windows.Forms.RadioButton sShirtSleeve;
        private System.Windows.Forms.RadioButton mShirt;
        private System.Windows.Forms.RadioButton sShirt;
        private System.Windows.Forms.RadioButton lShirt;
        private System.Windows.Forms.RadioButton lTrous;
        private System.Windows.Forms.RadioButton lJersey;
    }
}