﻿namespace TMT_SYSTEM
{
    partial class designPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbDesignType = new System.Windows.Forms.ComboBox();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.pBlack = new System.Windows.Forms.RadioButton();
            this.pBlue = new System.Windows.Forms.RadioButton();
            this.pWhite = new System.Windows.Forms.RadioButton();
            this.pGreen = new System.Windows.Forms.RadioButton();
            this.pRed = new System.Windows.Forms.RadioButton();
            this.sRed = new System.Windows.Forms.RadioButton();
            this.sYellow = new System.Windows.Forms.RadioButton();
            this.sGreen = new System.Windows.Forms.RadioButton();
            this.sBlue = new System.Windows.Forms.RadioButton();
            this.sWhite = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(316, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "JERSEY DESIGN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "DESIGN TYPE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(118, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "COLOUR SCHEME:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pBlack);
            this.groupBox1.Controls.Add(this.pBlue);
            this.groupBox1.Controls.Add(this.pWhite);
            this.groupBox1.Controls.Add(this.pGreen);
            this.groupBox1.Controls.Add(this.pRed);
            this.groupBox1.Location = new System.Drawing.Point(121, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 145);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PRIMARY COLOUR:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.sRed);
            this.groupBox2.Controls.Add(this.sYellow);
            this.groupBox2.Controls.Add(this.sGreen);
            this.groupBox2.Controls.Add(this.sBlue);
            this.groupBox2.Controls.Add(this.sWhite);
            this.groupBox2.Location = new System.Drawing.Point(420, 175);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(170, 145);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SECONDARY COLOUR:";
            // 
            // cmbDesignType
            // 
            this.cmbDesignType.FormattingEnabled = true;
            this.cmbDesignType.Location = new System.Drawing.Point(242, 90);
            this.cmbDesignType.Name = "cmbDesignType";
            this.cmbDesignType.Size = new System.Drawing.Size(121, 21);
            this.cmbDesignType.TabIndex = 7;
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(41, 404);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(103, 34);
            this.btnPrev.TabIndex = 8;
            this.btnPrev.Text = "PREVIOUS PAGE";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(632, 404);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(103, 34);
            this.btnNext.TabIndex = 9;
            this.btnNext.Text = "PROCEED";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // pBlack
            // 
            this.pBlack.AutoSize = true;
            this.pBlack.Location = new System.Drawing.Point(15, 19);
            this.pBlack.Name = "pBlack";
            this.pBlack.Size = new System.Drawing.Size(52, 17);
            this.pBlack.TabIndex = 10;
            this.pBlack.TabStop = true;
            this.pBlack.Text = "Black";
            this.pBlack.UseVisualStyleBackColor = true;
            // 
            // pBlue
            // 
            this.pBlue.AutoSize = true;
            this.pBlue.Location = new System.Drawing.Point(15, 42);
            this.pBlue.Name = "pBlue";
            this.pBlue.Size = new System.Drawing.Size(46, 17);
            this.pBlue.TabIndex = 11;
            this.pBlue.TabStop = true;
            this.pBlue.Text = "Blue";
            this.pBlue.UseVisualStyleBackColor = true;
            // 
            // pWhite
            // 
            this.pWhite.AutoSize = true;
            this.pWhite.Location = new System.Drawing.Point(15, 67);
            this.pWhite.Name = "pWhite";
            this.pWhite.Size = new System.Drawing.Size(53, 17);
            this.pWhite.TabIndex = 12;
            this.pWhite.TabStop = true;
            this.pWhite.Text = "White";
            this.pWhite.UseVisualStyleBackColor = true;
            // 
            // pGreen
            // 
            this.pGreen.AutoSize = true;
            this.pGreen.Location = new System.Drawing.Point(15, 90);
            this.pGreen.Name = "pGreen";
            this.pGreen.Size = new System.Drawing.Size(54, 17);
            this.pGreen.TabIndex = 13;
            this.pGreen.TabStop = true;
            this.pGreen.Text = "Green";
            this.pGreen.UseVisualStyleBackColor = true;
            // 
            // pRed
            // 
            this.pRed.AutoSize = true;
            this.pRed.Location = new System.Drawing.Point(15, 113);
            this.pRed.Name = "pRed";
            this.pRed.Size = new System.Drawing.Size(45, 17);
            this.pRed.TabIndex = 14;
            this.pRed.TabStop = true;
            this.pRed.Text = "Red";
            this.pRed.UseVisualStyleBackColor = true;
            // 
            // sRed
            // 
            this.sRed.AutoSize = true;
            this.sRed.Location = new System.Drawing.Point(29, 19);
            this.sRed.Name = "sRed";
            this.sRed.Size = new System.Drawing.Size(45, 17);
            this.sRed.TabIndex = 15;
            this.sRed.TabStop = true;
            this.sRed.Text = "Red";
            this.sRed.UseVisualStyleBackColor = true;
            // 
            // sYellow
            // 
            this.sYellow.AutoSize = true;
            this.sYellow.Location = new System.Drawing.Point(29, 42);
            this.sYellow.Name = "sYellow";
            this.sYellow.Size = new System.Drawing.Size(56, 17);
            this.sYellow.TabIndex = 16;
            this.sYellow.TabStop = true;
            this.sYellow.Text = "Yellow";
            this.sYellow.UseVisualStyleBackColor = true;
            // 
            // sGreen
            // 
            this.sGreen.AutoSize = true;
            this.sGreen.Location = new System.Drawing.Point(29, 67);
            this.sGreen.Name = "sGreen";
            this.sGreen.Size = new System.Drawing.Size(54, 17);
            this.sGreen.TabIndex = 17;
            this.sGreen.TabStop = true;
            this.sGreen.Text = "Green";
            this.sGreen.UseVisualStyleBackColor = true;
            this.sGreen.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // sBlue
            // 
            this.sBlue.AutoSize = true;
            this.sBlue.Location = new System.Drawing.Point(29, 90);
            this.sBlue.Name = "sBlue";
            this.sBlue.Size = new System.Drawing.Size(46, 17);
            this.sBlue.TabIndex = 18;
            this.sBlue.TabStop = true;
            this.sBlue.Text = "Blue";
            this.sBlue.UseVisualStyleBackColor = true;
            // 
            // sWhite
            // 
            this.sWhite.AutoSize = true;
            this.sWhite.Location = new System.Drawing.Point(29, 113);
            this.sWhite.Name = "sWhite";
            this.sWhite.Size = new System.Drawing.Size(53, 17);
            this.sWhite.TabIndex = 19;
            this.sWhite.TabStop = true;
            this.sWhite.Text = "White";
            this.sWhite.UseVisualStyleBackColor = true;
            // 
            // designPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 450);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.cmbDesignType);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "designPage";
            this.Text = "designPage";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbDesignType;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.RadioButton sBlue;
        private System.Windows.Forms.RadioButton sWhite;
        private System.Windows.Forms.RadioButton pBlack;
        private System.Windows.Forms.RadioButton pBlue;
        private System.Windows.Forms.RadioButton pWhite;
        private System.Windows.Forms.RadioButton pGreen;
        private System.Windows.Forms.RadioButton pRed;
        private System.Windows.Forms.RadioButton sRed;
        private System.Windows.Forms.RadioButton sYellow;
        private System.Windows.Forms.RadioButton sGreen;
    }
}