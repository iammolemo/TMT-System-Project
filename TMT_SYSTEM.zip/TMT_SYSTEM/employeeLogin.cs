﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TMT_SYSTEM
{
    public partial class employeeLogin : Form
    {
        SqlConnection con;
        string conString = @"Data Source=DESKTOP-DQF9S0M;Initial Catalog=TMT;Integrated Security=True";
        SqlCommand cmd;
        SqlDataReader myReader;
        public employeeLogin()
        {
            InitializeComponent();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeePage emp = new employeePage();
            emp.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(conString);
                con.Open();
                if (txtUsername.Text != "" && txtPassword.Text != "")
                {

                    string pass = txtPassword.Text;
                    string userNameAdmin = txtUsername.Text.ToLower();

                    string query = "SELECT * from [EMPLOYEE] WHERE Username ='" + txtUsername.Text + "' AND Password ='" + pass + "'";

                    if (txtPassword.Text == pass)
                    {
                        cmd = new SqlCommand(query, con);
                        myReader = cmd.ExecuteReader();
                        if (myReader.HasRows)
                        {
                            managerLogin maintain = new managerLogin();
                            maintain.Show(); //show the mainain page
                            myReader.Close();
                            this.Hide();

                        }
                        else
                        {
                            MessageBox.Show("Sorry, Username and password you entered doesn't belong to an account. Please double-check Your details and try again.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("The Username or Password is empty", "Information");
                }
                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}

       
